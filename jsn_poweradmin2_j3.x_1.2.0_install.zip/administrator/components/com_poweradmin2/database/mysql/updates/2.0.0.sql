ALTER TABLE `#__jsn_poweradmin2_favourite` CHANGE `icon` `icon` TEXT NOT NULL DEFAULT '';
ALTER TABLE `#__jsn_poweradmin2_history` CHANGE `component` `component` VARCHAR(255) NOT NULL DEFAULT '';
ALTER TABLE `#__jsn_poweradmin2_history` CHANGE `list_page` `list_page` VARCHAR(255) NOT NULL DEFAULT '';
ALTER TABLE `#__jsn_poweradmin2_history` CHANGE `list_page_params` `list_page_params` VARCHAR(255) NOT NULL DEFAULT '';
ALTER TABLE `#__jsn_poweradmin2_history` CHANGE `form` `form` TEXT NOT NULL DEFAULT '';
ALTER TABLE `#__jsn_poweradmin2_history` CHANGE `form_hash` `form_hash` VARCHAR(32) NOT NULL DEFAULT '';
ALTER TABLE `#__jsn_poweradmin2_history` CHANGE `icon` `icon` VARCHAR(255) NOT NULL DEFAULT '';
ALTER TABLE `#__jsn_poweradmin2_history` CHANGE `css` `css` VARCHAR(100) NOT NULL DEFAULT '';
