DROP TABLE IF EXISTS `#__jsn_poweradmin2_config`;
DROP TABLE IF EXISTS `#__jsn_poweradmin2_menu_assets`;
DROP TABLE IF EXISTS `#__jsn_poweradmin2_favourite`;
DROP TABLE IF EXISTS `#__jsn_poweradmin2_history`;
